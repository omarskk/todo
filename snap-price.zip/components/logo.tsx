import Image from "next/image"
import Link from "next/link"

interface LogoProps {
  className?: string
  size?: "small" | "medium" | "large"
}

export function Logo({ className = "", size = "medium" }: LogoProps) {
  // Définir les tailles en fonction du paramètre
  const sizes = {
    small: { width: 100, height: 40 },
    medium: { width: 150, height: 60 },
    large: { width: 200, height: 80 },
  }

  const { width, height } = sizes[size]

  return (
    <Link href="/" className={`block ${className}`}>
      <div className="relative" style={{ width, height }}>
        <Image
          src="/images/logo.png"
          alt="Snap Price Logo"
          fill
          priority
          className="object-contain"
          sizes={`(max-width: 768px) ${width / 1.5}px, ${width}px`}
        />
      </div>
    </Link>
  )
}

"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const stores = [
  { id: "electroshop", name: "ElectroShop" },
  { id: "techzone", name: "TechZone" },
  { id: "megastore", name: "MegaStore" },
  { id: "audioworld", name: "AudioWorld" },
  { id: "digitalcity", name: "DigitalCity" },
]

const categories = [
  { id: "smartphones", name: "Smartphones" },
  { id: "laptops", name: "Ordinateurs Portables" },
  { id: "tablets", name: "Tablettes" },
  { id: "headphones", name: "Écouteurs" },
  { id: "smartwatches", name: "Montres Connectées" },
]

export function FilterSidebar() {\
  const [priceRange  name: "Montres Connectées" },
]

export function FilterSidebar() {
  const [priceRange, setPriceRange] = useState([0, 1000])
  const [selectedStores, setSelectedStores] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])

  const handleStoreChange = (storeId: string) => {
    setSelectedStores((prev) => (prev.includes(storeId) ? prev.filter((id) => id !== storeId) : [...prev, storeId]))
  }

  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  const handlePriceChange = (value: number[]) => {
    setPriceRange(value)
  }

  const resetFilters = () => {
    setPriceRange([0, 1000])
    setSelectedStores([])
    setSelectedCategories([])
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Filtres</CardTitle>
        </CardHeader>
        <CardContent>
          <Button
            variant="ghost"
            size="sm"
            onClick={resetFilters}
            className="mb-4 text-primary hover:text-primary-700 hover:bg-primary-50 w-full"
          >
            Réinitialiser les filtres
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Prix</CardTitle>
        </CardHeader>
        <CardContent>
          <Slider
            defaultValue={[0, 1000]}
            max={1000}
            step={10}
            value={priceRange}
            onValueChange={handlePriceChange}
            className="my-6"
          />
          <div className="flex justify-between">
            <span>{priceRange[0]} €</span>
            <span>{priceRange[1]} €</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Catégories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center space-x-2">
                <Checkbox
                  id={`category-${category.id}`}
                  checked={selectedCategories.includes(category.id)}
                  onCheckedChange={() => handleCategoryChange(category.id)}
                />
                <Label htmlFor={`category-${category.id}`}>{category.name}</Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Vendeurs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stores.map((store) => (
              <div key={store.id} className="flex items-center space-x-2">
                <Checkbox
                  id={`store-${store.id}`}
                  checked={selectedStores.includes(store.id)}
                  onCheckedChange={() => handleStoreChange(store.id)}
                />
                <Label htmlFor={`store-${store.id}`}>{store.name}</Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

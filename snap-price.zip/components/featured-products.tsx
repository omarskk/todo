import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const featuredProducts = [
  {
    id: 1,
    name: "Smartphone XYZ Pro",
    image: "/placeholder.svg?height=200&width=200",
    minPrice: 499.99,
    maxPrice: 599.99,
    savings: 100,
    stores: 5,
  },
  {
    id: 2,
    name: "Écouteurs Sans Fil Premium",
    image: "/placeholder.svg?height=200&width=200",
    minPrice: 89.99,
    maxPrice: 129.99,
    savings: 40,
    stores: 7,
  },
  {
    id: 3,
    name: "Tablette Ultra HD",
    image: "/placeholder.svg?height=200&width=200",
    minPrice: 299.99,
    maxPrice: 399.99,
    savings: 100,
    stores: 4,
  },
  {
    id: 4,
    name: "Montre Connectée Sport",
    image: "/placeholder.svg?height=200&width=200",
    minPrice: 149.99,
    maxPrice: 199.99,
    savings: 50,
    stores: 6,
  },
]

export function FeaturedProducts() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {featuredProducts.map((product) => (
        <Link href={`/product/${product.id}`} key={product.id}>
          <Card className="h-full transition-all duration-200 hover:shadow-md snap-price-card-hover">
            <CardContent className="p-4">
              <div className="relative h-48 mb-4">
                <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-contain" />
              </div>
              <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.name}</h3>
              <div className="flex justify-between items-center mb-2">
                <span className="text-primary-700 font-bold">{product.minPrice.toFixed(2)} €</span>
                <span className="text-gray-500 text-sm line-through">{product.maxPrice.toFixed(2)} €</span>
              </div>
              <div className="flex justify-between items-center">
                <Badge variant="outline" className="bg-secondary-50 text-secondary-700 border-secondary-200">
                  Économisez {product.savings} €
                </Badge>
                <span className="text-xs text-gray-500">{product.stores} vendeurs</span>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

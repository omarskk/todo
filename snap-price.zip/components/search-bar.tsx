"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SearchBar() {
  const [query, setQuery] = useState("")
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query)}`)
    }
  }

  return (
    <form onSubmit={handleSearch} className="relative">
      <div className="flex w-full max-w-2xl mx-auto">
        <Input
          type="text"
          placeholder="Recherchez un produit..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="rounded-l-lg py-6 text-lg border-r-0 focus-visible:ring-primary"
        />
        <Button type="submit" className="rounded-l-none bg-primary hover:bg-primary-600 text-white px-6">
          <Search className="mr-2 h-5 w-5" />
          <span className="hidden sm:inline">Rechercher</span>
        </Button>
      </div>
    </form>
  )
}

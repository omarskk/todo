import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, ThumbsUp } from "lucide-react"

// Mock data - in a real app, this would come from an API
const mockProducts = [
  {
    id: 101,
    name: "Smartphone Galaxy Ultra",
    image: "/placeholder.svg?height=150&width=150",
    description: "Smartphone haut de gamme avec appareil photo professionnel",
    prices: [
      { store: "ElectroShop", price: 899.99, link: "#" },
      { store: "TechZone", price: 929.99, link: "#" },
      { store: "MegaStore", price: 879.99, link: "#" },
    ],
    rating: 4.7,
    reviews: 128,
  },
  {
    id: 102,
    name: "Écouteurs Sans Fil Pro",
    image: "/placeholder.svg?height=150&width=150",
    description: "Écouteurs avec réduction de bruit active et son immersif",
    prices: [
      { store: "AudioWorld", price: 149.99, link: "#" },
      { store: "ElectroShop", price: 159.99, link: "#" },
      { store: "TechZone", price: 139.99, link: "#" },
    ],
    rating: 4.5,
    reviews: 86,
  },
  {
    id: 103,
    name: "Tablette Pro 11 pouces",
    image: "/placeholder.svg?height=150&width=150",
    description: "Tablette performante avec écran haute résolution",
    prices: [
      { store: "TechZone", price: 449.99, link: "#" },
      { store: "MegaStore", price: 429.99, link: "#" },
      { store: "ElectroShop", price: 469.99, link: "#" },
    ],
    rating: 4.6,
    reviews: 74,
  },
]

export function ProductList({ query }: { query: string }) {
  // In a real app, we would filter products based on the query
  const products = mockProducts

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Aucun produit trouvé pour "{query}"</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {products.map((product) => (
        <Card key={product.id} className="overflow-hidden snap-price-shadow">
          <CardContent className="p-0">
            <div className="flex flex-col md:flex-row">
              <div className="w-full md:w-1/4 p-6 flex items-center justify-center bg-white">
                <div className="relative h-32 w-32">
                  <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-contain" />
                </div>
              </div>

              <div className="w-full md:w-3/4 p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <Link href={`/product/${product.id}`}>
                      <h2 className="text-xl font-bold hover:text-primary transition-colors">{product.name}</h2>
                    </Link>
                    <p className="text-gray-600 mt-1">{product.description}</p>

                    <div className="flex items-center mt-2">
                      <div className="flex items-center">
                        <ThumbsUp className="h-4 w-4 text-primary mr-1" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                      <span className="mx-2 text-gray-300">|</span>
                      <span className="text-sm text-gray-500">{product.reviews} avis</span>
                    </div>
                  </div>

                  <Badge className="bg-secondary-100 text-secondary-800 border-0">
                    Économisez{" "}
                    {(
                      Math.max(...product.prices.map((p) => p.price)) - Math.min(...product.prices.map((p) => p.price))
                    ).toFixed(2)}{" "}
                    €
                  </Badge>
                </div>

                <div className="mt-6 space-y-3">
                  {product.prices
                    .sort((a, b) => a.price - b.price)
                    .map((price, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center p-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                      >
                        <div className="font-medium">{price.store}</div>
                        <div className="flex items-center gap-4">
                          <span className={`font-bold ${index === 0 ? "text-primary-600" : "text-gray-700"}`}>
                            {price.price.toFixed(2)} €
                          </span>
                          <Button
                            asChild
                            variant="outline"
                            size="sm"
                            className="gap-1 border-primary text-primary hover:bg-primary/10"
                          >
                            <Link href={price.link}>
                              <ExternalLink className="h-4 w-4" />
                              <span>Voir</span>
                            </Link>
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

import { Search, BarChart2, ShoppingCart } from "lucide-react"

const steps = [
  {
    icon: Search,
    title: "Recherchez",
    description: "Entrez le nom du produit que vous souhaitez acheter",
  },
  {
    icon: BarChart2,
    title: "Comparez",
    description: "Consultez les prix proposés par différents vendeurs",
  },
  {
    icon: ShoppingCart,
    title: "Économisez",
    description: "Choisissez le meilleur prix et faites des économies",
  },
]

export function HowItWorks() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto px-4">
      {steps.map((step, index) => (
        <div key={index} className="flex flex-col items-center text-center">
          <div className="bg-primary-100 p-4 rounded-full mb-4">
            <step.icon className="h-8 w-8 text-primary-600" />
          </div>
          <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
          <p className="text-gray-600">{step.description}</p>
        </div>
      ))}
    </div>
  )
}

"use client"
import Link from "next/link"
import { Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Logo } from "@/components/logo"

export function Navbar() {
  return (
    <header className="flex h-20 w-full shrink-0 items-center justify-between px-4 md:px-6 border-b bg-white snap-price-shadow">
      {/* Left section */}
      <div className="flex items-center">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="lg:hidden">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <div className="flex justify-center mb-8">
              <Logo size="medium" />
            </div>
            <div className="grid gap-2 py-6">
              <Link href="/" className="flex w-full items-center py-2 text-lg font-semibold">
                Accueil
              </Link>
              <Link href="/categories" className="flex w-full items-center py-2 text-lg font-semibold">
                Catégories
              </Link>
              <Link href="/deals" className="flex w-full items-center py-2 text-lg font-semibold">
                Bonnes Affaires
              </Link>
              <Link href="/trending" className="flex w-full items-center py-2 text-lg font-semibold">
                Tendances
              </Link>
              <Link href="/contact" className="flex w-full items-center py-2 text-lg font-semibold">
                Contact
              </Link>
            </div>
          </SheetContent>
        </Sheet>

        <nav className="hidden lg:flex gap-6 ml-6">
          <Link href="/" className="text-md font-medium hover:text-primary transition-colors">
            Accueil
          </Link>
          <Link href="/categories" className="text-md font-medium hover:text-primary transition-colors">
            Catégories
          </Link>
        </nav>
      </div>

      {/* Center section - Logo */}
      <div className="absolute left-1/2 transform -translate-x-1/2">
        <Logo size="medium" />
      </div>

      {/* Right section */}
      <div className="flex items-center gap-6">
        <nav className="hidden lg:flex gap-6">
          <Link href="/deals" className="text-md font-medium hover:text-primary transition-colors">
            Bonnes Affaires
          </Link>
          <Link href="/trending" className="text-md font-medium hover:text-primary transition-colors">
            Tendances
          </Link>
        </nav>
        <div className="flex gap-2">
          <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
            Connexion
          </Button>
          <Button className="bg-primary hover:bg-primary-600 text-white hidden sm:inline-flex">Inscription</Button>
        </div>
      </div>
    </header>
  )
}

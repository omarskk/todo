import type { Config } from "tailwindcss"

const config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        // Couleurs principales basées sur le logo
        primary: {
          DEFAULT: "#6A3EA1", // Violet du logo
          50: "#F3EFFA",
          100: "#E7DFF5",
          200: "#D0BFEB",
          300: "#B89FE0",
          400: "#A17FD6",
          500: "#8A5FCB",
          600: "#7A4DB8",
          700: "#6A3EA1", // Couleur de base
          800: "#5A3487",
          900: "#4A2A6E",
        },
        secondary: {
          DEFAULT: "#78C13A", // Vert du logo
          50: "#F2F9EA",
          100: "#E5F3D5",
          200: "#CBE7AB",
          300: "#B1DB81",
          400: "#97CF57",
          500: "#78C13A", // Couleur de base
          600: "#62A02F",
          700: "#4D7F25",
          800: "#395E1B",
          900: "#243D11",
        },
        // Nuances de gris
        gray: {
          50: "#F9FAFB",
          100: "#F3F4F6",
          200: "#E5E7EB",
          300: "#D1D5DB",
          400: "#9CA3AF",
          500: "#6B7280",
          600: "#4B5563",
          700: "#374151",
          800: "#1F2937",
          900: "#111827",
        },
        // Couleurs d'état
        success: "#10B981",
        warning: "#FBBF24",
        error: "#EF4444",
        info: "#3B82F6",
        // Couleurs de fond et de texte
        background: "#FFFFFF",
        foreground: "#111827",
        // Couleurs pour les composants
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config

export default config

import { SearchBar } from "@/components/search-bar"
import { FeaturedProducts } from "@/components/featured-products"
import { HowItWorks } from "@/components/how-it-works"
import { Footer } from "@/components/footer"
import { Navbar } from "@/components/navbar"

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="py-12 md:py-20 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-gray-900">
            Trouvez le <span className="text-secondary">meilleur prix</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Comparez les prix de vos produits préférés en un instant
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <SearchBar />
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-12">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-gray-800">Produits Populaires</h2>
          <FeaturedProducts />
        </section>

        {/* How It Works */}
        <section className="py-12 bg-white rounded-xl shadow-sm my-8">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-gray-800">Comment Ça Marche</h2>
          <HowItWorks />
        </section>
      </main>

      <Footer />
    </div>
  )
}

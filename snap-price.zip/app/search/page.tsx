import { SearchBar } from "@/components/search-bar"
import { ProductList } from "@/components/product-list"
import { FilterSidebar } from "@/components/filter-sidebar"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q: string }
}) {
  const query = searchParams.q || ""

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <SearchBar />
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/4">
            <FilterSidebar />
          </div>

          <div className="w-full md:w-3/4">
            <h1 className="text-2xl font-bold mb-6">Résultats pour "{query}"</h1>
            <ProductList query={query} />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

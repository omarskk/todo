import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, BarChart2, ShoppingCart } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

// Mock product data - in a real app, this would come from an API
const products = [
  {
    id: "1",
    name: "Smartphone Galaxy Ultra",
    description:
      "Le dernier smartphone haut de gamme avec un appareil photo professionnel, un écran AMOLED de 6,8 pouces et une batterie longue durée.",
    fullDescription:
      "Le Smartphone Galaxy Ultra est l'appareil ultime pour les utilisateurs exigeants. Doté d'un processeur octa-core ultra-rapide, d'un système de caméra professionnel avec zoom optique 10x, et d'une batterie de 5000mAh qui dure toute la journée. L'écran AMOLED de 6,8 pouces offre des couleurs vibrantes et un taux de rafraîchissement de 120Hz pour une expérience visuelle fluide. Résistant à l'eau et à la poussière avec certification IP68.",
    specifications: [
      { name: "Écran", value: "AMOLED 6,8 pouces, 120Hz" },
      { name: "Processeur", value: "Octa-core 3.0 GHz" },
      { name: "RAM", value: "12 GB" },
      { name: "Stockage", value: "256 GB" },
      { name: "Batterie", value: "5000 mAh" },
      { name: "Caméra principale", value: "108 MP + 12 MP + 10 MP" },
      { name: "Caméra frontale", value: "40 MP" },
      { name: "Système d'exploitation", value: "Android 13" },
    ],
    images: [
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
    ],
    prices: [
      { store: "ElectroShop", price: 899.99, link: "#", delivery: "Livraison gratuite", availability: "En stock" },
      { store: "TechZone", price: 929.99, link: "#", delivery: "Livraison: 4.99€", availability: "En stock" },
      {
        store: "MegaStore",
        price: 879.99,
        link: "#",
        delivery: "Livraison gratuite",
        availability: "Expédition sous 2 jours",
      },
      { store: "DigitalCity", price: 949.99, link: "#", delivery: "Livraison gratuite", availability: "En stock" },
    ],
    rating: 4.7,
    reviews: 128,
    priceHistory: [
      { date: "Jan", price: 999.99 },
      { date: "Fév", price: 979.99 },
      { date: "Mar", price: 949.99 },
      { date: "Avr", price: 929.99 },
      { date: "Mai", price: 899.99 },
      { date: "Juin", price: 879.99 },
    ],
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = products.find((p) => p.id === params.id)

  if (!product) {
    notFound()
  }

  const lowestPrice = Math.min(...product.prices.map((p) => p.price))
  const highestPrice = Math.max(...product.prices.map((p) => p.price))
  const saving = highestPrice - lowestPrice

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-emerald-600 hover:underline">
            Accueil
          </Link>
          {" > "}
          <span className="text-gray-600">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Product Images */}
          <div className="col-span-1">
            <div className="bg-white rounded-lg p-4 mb-4">
              <div className="relative h-80 w-full">
                <Image
                  src={product.images[0] || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-contain"
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {product.images.map((image, index) => (
                <div key={index} className="bg-white rounded-lg p-2 cursor-pointer">
                  <div className="relative h-20 w-full">
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} - vue ${index + 1}`}
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="col-span-1 lg:col-span-2">
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>

            <div className="flex items-center mb-4">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                <span className="ml-1 font-medium">{product.rating}</span>
              </div>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-gray-600">{product.reviews} avis</span>
            </div>

            <p className="text-gray-700 mb-6">{product.description}</p>

            <div className="bg-emerald-50 p-4 rounded-lg mb-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-600">Prix le plus bas</p>
                  <p className="text-2xl font-bold text-emerald-600">{lowestPrice.toFixed(2)} €</p>
                </div>
                <Badge className="bg-emerald-100 text-emerald-800 border-0 text-sm">
                  Économisez jusqu'à {saving.toFixed(2)} €
                </Badge>
              </div>
            </div>

            <Tabs defaultValue="prices" className="mb-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="prices">Prix</TabsTrigger>
                <TabsTrigger value="specs">Caractéristiques</TabsTrigger>
                <TabsTrigger value="history">Historique des prix</TabsTrigger>
              </TabsList>

              <TabsContent value="prices" className="mt-4">
                <div className="space-y-3">
                  {product.prices
                    .sort((a, b) => a.price - b.price)
                    .map((price, index) => (
                      <Card key={index} className={index === 0 ? "border-emerald-300" : ""}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <h3 className="font-semibold text-lg">{price.store}</h3>
                              <p className="text-sm text-gray-600">{price.availability}</p>
                              <p className="text-sm text-gray-600">{price.delivery}</p>
                            </div>
                            <div className="text-right">
                              <p className={`text-xl font-bold ${index === 0 ? "text-emerald-600" : "text-gray-800"}`}>
                                {price.price.toFixed(2)} €
                              </p>
                              <Button asChild variant="outline" size="sm" className="mt-2">
                                <Link href={price.link}>
                                  <ShoppingCart className="h-4 w-4 mr-2" />
                                  Acheter
                                </Link>
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="specs" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.specifications.map((spec, index) => (
                    <div key={index} className="flex justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium text-gray-700">{spec.name}</span>
                      <span className="text-gray-900">{spec.value}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="history" className="mt-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold mb-4 flex items-center">
                    <BarChart2 className="h-5 w-5 mr-2 text-emerald-600" />
                    Évolution du prix sur 6 mois
                  </h3>
                  <div className="h-64 flex items-end justify-between">
                    {product.priceHistory.map((point, index) => (
                      <div key={index} className="flex flex-col items-center">
                        <div
                          className="bg-emerald-500 w-12 rounded-t-md"
                          style={{
                            height: `${(point.price / 1000) * 200}px`,
                            opacity: 0.6 + index / (product.priceHistory.length * 2),
                          }}
                        ></div>
                        <div className="mt-2 text-xs text-gray-600">{point.date}</div>
                        <div className="text-xs font-medium">{point.price.toFixed(0)}€</div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-6">
              <h2 className="text-xl font-bold mb-4">Description détaillée</h2>
              <p className="text-gray-700">{product.fullDescription}</p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
